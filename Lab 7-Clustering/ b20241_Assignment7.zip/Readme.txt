All program codes are present in single file only. Proper divisions between all the question have been done.
Thanka and regards
Yash Sharma (B20241)